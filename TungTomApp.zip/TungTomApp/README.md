# TrollModPoke APK

App Android (WebView) chạy userscript **TungTom v1.11.0** cho pokesurvivor.com / pokesurvivor.doofcraft.com.
Menu điều khiển nằm trong app (nút 🍤 kéo được ở góc màn hình) thay cho bảng trong trang.

## Build APK
**Cách 1 – GitHub Actions (không cần máy tính):** tạo repo GitHub, upload toàn bộ thư mục này
(giữ nguyên `.github/`), vào tab *Actions* → *Build APK* → tải artifact `TungTom-apk`.

**Cách 2 – Android Studio:** Open thư mục này → Build → Build APK(s) → `app/build/outputs/apk/debug/`.

## Menu (6 tab, nút to, tab nằm cạnh trái khi xoay ngang / đáy khi xoay dọc)
- 🎮 **Bot**: Chơi / Dừng / Tạm dừng / Tiếp tục, số ván (− +), overlay debug, chế độ ván doofcraft.
- 📺 **Màn nhỏ**: bản thu nhỏ của trang. Chạm/kéo trên khung = chạm/kéo thật trong game (app đẩy cú chạm hệ thống vào
  WebView). Chỉnh tốc độ vẽ (2/5/10/20 khung/giây), kiểu vẽ, nội dung, và mở **toàn màn hình**.
- 🎰 **Gacha/Shop**: chọn Gen 1–9, số lượt quay, x1/x10 rồi "Quay gacha"; "Cộng hết điểm Upgrade" (có công tắc tự cộng
  sau mỗi ván); "Mở Shop của game". Tất cả chỉ **bấm đúng nút trên màn hình game** như người chơi (không sửa save/xu/vé).
  Game đặt tên nút khác thì dùng "Dò giao diện game" → sao chép → gửi lại để chỉnh cho khớp.
- ⚡ **Giảm lag**, 👤 **Tài khoản** (tự điền & đăng nhập), ⚙ **Cài đặt**.
- Có lớp **giám sát** trong `bridge.js`: nếu thua/menu đứng yên > 9 giây khi bot đang bật thì tự đóng popup, bấm Lưu game
  (chờ tối đa 15 giây) rồi chơi ván tiếp, dùng các id của game (`scr-over`, `btn-again`, `btn-save`, `data-go=play`).
- Userscript trong `assets/TungTom_user.js` là bản **PokeSurvivor Lite 1.10.0** (đã đổi màu nhấn sang xanh dương).
Mã vẽ khung thu nhỏ, đăng nhập, gacha/upgrade/shop và giám sát nằm trong `assets/bridge.js`.

## Cập nhật script
Chép đè `app/src/main/assets/TungTom_user.js` rồi build lại.

## Lưu ý
- Userscript được tiêm ở document-start (giống Via/Tampermonkey), nên hook game hoạt động như bản gốc.
- Nút "Xuất data.js" (tải file) của bảng F6 không dùng được trong WebView; phím F6–F9 cũng không có trên điện thoại.
- Gốc: damhieu2808/PokeSurvivorTool (MIT).
